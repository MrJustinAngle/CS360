package com.example.project;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    // creating variables for our edittext, button and dbhandler
    private EditText weightEdit, dateEdit, goalEdit;
    private Button addWeight, back;
    private DBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // initializing all our variables.
        weightEdit = findViewById(R.id.editWeight);
        dateEdit = findViewById(R.id.editDate);
        goalEdit = findViewById(R.id.editGoalWeight);
        addWeight = findViewById(R.id.submit);
        back = findViewById(R.id.back);

        // creating a new dbhandler class and passing the context
        dbHandler = new DBHandler(MainActivity3.this);

        // below line is to add on click listener to the add button.
        addWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String weight = weightEdit.getText().toString();
                String date = dateEdit.getText().toString();
                String goalWeight = goalEdit.getText().toString();

                if (weight.isEmpty() || date.isEmpty() || goalWeight.isEmpty()) {
                    Toast.makeText(MainActivity3.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
                    return;
                }

                dbHandler.addNewWeight(weight, date, goalWeight);

                Toast.makeText(MainActivity3.this, "New weight has been added.", Toast.LENGTH_SHORT).show();
                weightEdit.setText("");
                dateEdit.setText("");
                goalEdit.setText("");
            }
        });

        // This allows us to go back to where the data is shown
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity3.this, MainActivity2.class);
                startActivity(i);
            }
        });
    }
}