package com.example.project;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;



public class WeightRVAdapter extends RecyclerView.Adapter<WeightRVAdapter.ViewHolder> {

    // variable for our array list and context
    private ArrayList<WeightModal> weightModalArrayList;
    private Context context;

    // constructor
    public WeightRVAdapter(ArrayList<WeightModal> courseModalArrayList, Context context) {
        this.weightModalArrayList = courseModalArrayList;
        this.context = context;
    }

    // Creates a view holder
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_rv_item, parent, false);
        return new ViewHolder(view);
    }

    // Setting the data to the recycler view items
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        WeightModal modal = weightModalArrayList.get(position);
        holder.currentWeight.setText(modal.getCurrentWeight());
        holder.date.setText(modal.getDate());
        holder.goalWeight.setText(modal.getGoalWeight());
    }

    // Returns the size of the array list
    @Override
    public int getItemCount() {
        return weightModalArrayList.size();
    }

    // Creates the variables for text values and initializes out views
    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView currentWeight, date, goalWeight;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            currentWeight = itemView.findViewById(R.id.showWeight);
            date = itemView.findViewById(R.id.showDate);
            goalWeight = itemView.findViewById(R.id.showGoalWeight);
        }
    }
}