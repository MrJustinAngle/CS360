package com.example.project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {

    private static final String DB_NAME = "weightdb";

    private static final int DB_VERSION = 1;

    private static final String TABLE_NAME = "myweight";

    private static final String ID_COL = "id";

    private static final String WEIGHT = "weight";

    private static final String DATE = "date";

    private static final String GOAL_WEIGHT = "goal";



    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // To create the database
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + WEIGHT + " TEXT,"
                + DATE + " TEXT,"
                + GOAL_WEIGHT + " TEXT)";

        db.execSQL(query);
    }

    // This method allows us to add the inserted data
    public void addNewWeight(String weight, String date, String goalWeight) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(WEIGHT, weight);
        values.put(DATE, date);
        values.put(GOAL_WEIGHT, goalWeight);

        db.insert(TABLE_NAME, null, values);

        db.close();
    }

    // This method allows us to read all the inserted data
    public ArrayList<WeightModal> readWeight() {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorWeight = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        ArrayList<WeightModal> weightModalArrayList = new ArrayList<>();

        if (cursorWeight.moveToFirst()) {
            do {
                weightModalArrayList.add(new WeightModal(cursorWeight.getString(1),
                        cursorWeight.getString(2),
                        cursorWeight.getString(3)));
            } while (cursorWeight.moveToNext());
        }
        cursorWeight.close();
        return weightModalArrayList;
    }

    // This method allows us to check if a table already exists
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}